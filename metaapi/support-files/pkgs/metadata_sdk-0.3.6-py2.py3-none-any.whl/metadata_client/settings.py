# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making BK-BASE 蓝鲸基础平台 available.
Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
BK-BASE 蓝鲸基础平台 is licensed under the MIT License.
License for BK-BASE 蓝鲸基础平台:
--------------------------------------------------------------------
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial
portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""


from copy import deepcopy

from metadata_client.exc import GetEndpointError


class DefaultSettings(object):

    META_API_HOST = "127.0.0.1"
    META_API_PORT = "80"
    META_API_ROUTE_TEMPLATE = "v3/meta/{ROUTE}/"

    COMPLEX_SEARCH_TEMPLATE = META_API_ROUTE_TEMPLATE.format(ROUTE="basic/entity/complex_search")
    QUERY_VIA_ERP_TEMPLATE = META_API_ROUTE_TEMPLATE.format(ROUTE="basic/asset/query_via_erp")
    ENTITY_EDIT_TEMPLATE = META_API_ROUTE_TEMPLATE.format(ROUTE="basic/entity/edit")
    BRIDGE_SYNC_TEMPLATE = META_API_ROUTE_TEMPLATE.format(ROUTE="sync")
    EVENT_SUPPORTER_TEMPLATE = META_API_ROUTE_TEMPLATE.format(ROUTE="event_supports")

    CRYPT_INSTANCE_KEY = ""
    ROOT_IV = ""
    ROOT_KEY = ""

    BKDATA_LOG_DB_RECYCLE = 3600

    # 同步内容类型 id/content
    SYNC_CONTENT_TYPE = "id"
    # 批量同步标志
    SYNC_BATCH_FLAG = False

    def copy(self):
        return deepcopy(self)

    def update(self, settings_info):
        for k, v in settings_info.items():
            setattr(self, k, v)

    def endpoints(self, key):
        endpoints_mapping = {
            "complex_search": self.COMPLEX_SEARCH_TEMPLATE,
            "query_via_erp": self.QUERY_VIA_ERP_TEMPLATE,
            "entity_edit": self.ENTITY_EDIT_TEMPLATE,
            "bridge_sync": self.BRIDGE_SYNC_TEMPLATE,
            "event_support": self.EVENT_SUPPORTER_TEMPLATE,
        }
        if key in endpoints_mapping:
            endpoint_template = "http://{META_API_HOST}:{META_API_PORT}/" + endpoints_mapping[key]
            return endpoint_template.format(META_API_HOST=self.META_API_HOST, META_API_PORT=self.META_API_PORT)
        raise GetEndpointError(message_kv={"detail": key})


DEFAULT_SETTINGS = DefaultSettings()
