# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making BK-BASE 蓝鲸基础平台 available.
Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
BK-BASE 蓝鲸基础平台 is licensed under the MIT License.
License for BK-BASE 蓝鲸基础平台:
--------------------------------------------------------------------
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial
portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""


import re
from abc import ABCMeta

first_cap_re = re.compile("(.)([A-Z][a-z]+)")
all_cap_re = re.compile("([a-z0-9])([A-Z])")


def camel_to_snake(name):
    """将驼峰式命名变更为下划线小写命名。"""
    s1 = first_cap_re.sub(r"\1_\2", name)
    return all_cap_re.sub(r"\1_\2", s1).lower()


def snake_to_camel(snake_str, apply_to_first=False):
    """将标准Python变量名转换为驼峰式命名。"""
    components = snake_str.split("_")
    first_component = components[0] if not apply_to_first else components[0].title()
    return first_component + "".join(x.title() for x in components[1:])


class StrictABCMeta(ABCMeta):
    def __new__(mcs, name, bases, namespace):
        """
        严格的抽象元类。除了ABCMeta本身功能，提供增强功能：禁止显式抽象类(__abstract__属性为True)实例化。
        """
        cls = super(StrictABCMeta, mcs).__new__(mcs, name, bases, namespace)

        if not namespace.get("__abstract__"):
            cls.__abstract__ = False

        if cls.__abstract__ and (True not in [getattr(base, "__abstract__", False) for base in bases]):

            def new(now_cls, *args, **kwargs):
                """
                若类被标注为显式抽象类(__abstract__属性为True)，则无法实例化。
                """
                if getattr(now_cls, "__abstract__", False):
                    raise TypeError("Can't instantiate explicit abstract class.")
                return super(cls, now_cls).__new__(now_cls, *args, **kwargs)

            cls.__new__ = staticmethod(new)

        return cls


class abstractclassmethod(classmethod):
    __isabstractmethod__ = True

    def __init__(self, callable):
        callable.__isabstractmethod__ = True
        super(abstractclassmethod, self).__init__(callable)


class _Empty(object):
    def __nonzero__(self):
        return False


Empty = _Empty()
