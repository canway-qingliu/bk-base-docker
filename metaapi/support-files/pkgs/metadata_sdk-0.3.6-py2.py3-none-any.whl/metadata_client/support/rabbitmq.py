# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making BK-BASE 蓝鲸基础平台 available.
Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
BK-BASE 蓝鲸基础平台 is licensed under the MIT License.
License for BK-BASE 蓝鲸基础平台:
--------------------------------------------------------------------
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial
portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""


# rabbitmq 中间件
import enum

import requests
from kombu import Connection, Consumer, Exchange, Queue
from metadata_client.exc import EventSubscribeConfigError
from metadata_client.support.base_crypt import BaseCrypt


class ExchangeType(enum.Enum):
    DIRECT = "direct"  # 1:1绑定
    TOPIC = "topic"  # N:1绑定
    FANOUT = "fanout"  # 1:N绑定
    HEADERS = "headers"


class RabbitMQConsumer(object):
    def __init__(
        self, backend, queue_mapping=None, exchange_name="", exchange_type=ExchangeType.TOPIC.value, callbacks=None
    ):
        self.queue_mapping = queue_mapping if queue_mapping else dict()
        self.exchange_type = exchange_type
        self.exchange = Exchange(str(exchange_name), type=str(exchange_type))
        self.listening_queues = self._get_listening_queues()
        self.callbacks = callbacks if callbacks else []
        backend.get_backend_config()
        backend.decrypt_addr()
        self.conn = Connection(backend.addr)

    def release(self):
        """
        释放连接

        :return:
        """

        self.conn.release()

    def _get_listening_queues(self):
        """
        获取监听的队列列表

        :return: list 根据配置声明的队列列表
        """

        listening_queues = []
        if not self.queue_mapping or not isinstance(self.queue_mapping, dict):
            raise
        for queue_name, queue_config in self.queue_mapping.items():
            listening_queues.append(
                Queue(name=str(queue_name), routing_key=str(queue_config["routing_key"]), exchange=self.exchange)
            )
        return listening_queues

    def start_scan(self, timeout=1):
        """
        开始消耗

        :return: None
        """
        with Consumer(self.conn, queues=self.listening_queues, callbacks=self.callbacks):
            self.conn.drain_events(timeout=timeout)


class BackendClient(object):
    """
    事件系统队列后端Client
    """

    def __init__(self, supports_config):
        """
        :param supports_config: 事件系统相关配置参数的获取支持
        """
        self.supports_config = supports_config
        self.method = "GET"
        self.backend_config = None
        self.addr = None

    def get_backend_config(self):
        """
        获取队列后端配置参数

        :return: dict
        """
        resp = requests.get(url=self.supports_config["supporter"])
        try:
            resp.raise_for_status()
            response_result = resp.json()
        except Exception as he:
            message = "初始化RABBITMQ错误: {}".format(he)
            raise EventSubscribeConfigError(message_kv={"detail": message})
        self.backend_config = response_result["data"]

    def decrypt_addr(self):
        """
        解码队列后端地址

        :return:
        """
        crypt = BaseCrypt(**self.supports_config)
        self.addr = crypt.decrypt(self.backend_config["addr"])
