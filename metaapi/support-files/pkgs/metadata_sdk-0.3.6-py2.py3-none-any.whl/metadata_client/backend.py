# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making BK-BASE 蓝鲸基础平台 available.
Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
BK-BASE 蓝鲸基础平台 is licensed under the MIT License.
License for BK-BASE 蓝鲸基础平台:
--------------------------------------------------------------------
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial
portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""


import functools
import logging

from metadata_client.exc import RPCProcedureError
from metadata_client.resource import http_session

module_logger = logging.getLogger(__name__)


def pre_query():
    def __func(func):
        @functools.wraps(func)
        def _func(*args, **kwargs):
            try:
                rpc_extra = kwargs.get(str("rpc_extra"), {})
                kwargs[str("rpc_extra")] = rpc_extra
                resp = func(*args, **kwargs)
                resp.raise_for_status()
            except Exception as e:
                module_logger.exception("Query to metaapi failed. detail: {}".format(e))
                raise
            if resp:
                resp_data = resp.json()
                if resp_data.get("result", None) and "data" in resp_data:
                    return resp_data["data"]
                return resp_data
            else:
                raise RPCProcedureError(message_kv={"error": "Query返回结果为空."})

        return _func

    return __func


class ApiBackendMixIn(object):

    settings = None

    @pre_query()
    def entity_complex_search(self, statement, backend_type="mysql", **kwargs):
        kwargs[str("statement")] = statement
        kwargs[str("backend_type")] = backend_type
        return http_session.post(self.settings.endpoints("complex_search"), data=None, json=kwargs)

    @pre_query()
    def entity_query_via_erp(self, retrieve_args, **kwargs):
        kwargs[str("retrieve_args")] = retrieve_args
        return http_session.post(self.settings.endpoints("query_via_erp"), data=None, json=kwargs)

    @pre_query()
    def entity_edit(self, operate_records_lst, **kwargs):
        kwargs[str("operate_records_lst")] = operate_records_lst
        return http_session.post(self.settings.endpoints("entity_edit"), data=None, json=kwargs)

    @pre_query()
    def bridge_sync(self, sync_contents, content_mode="id", batch=False, **kwargs):
        kwargs[str("db_operations_list")] = sync_contents
        kwargs[str("content_mode")] = content_mode
        kwargs[str("batch")] = batch
        return http_session.post(self.settings.endpoints("bridge_sync"), data=None, json=kwargs)
