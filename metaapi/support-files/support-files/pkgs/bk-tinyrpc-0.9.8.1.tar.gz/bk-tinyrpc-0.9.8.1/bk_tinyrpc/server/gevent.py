#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import
import gevent

from . import RPCServer


class RPCServerGreenlets(RPCServer):

    def __init__(self, transport, protocol, dispatcher, spawn_func=None):
        # custom spawn_func to support concurrent pool.
        self.spawn_func = gevent.spawn if not spawn_func else spawn_func
        super(RPCServerGreenlets, self).__init__(transport, protocol, dispatcher)

    # documentation in docs because of dependencies
    def _spawn(self, func, *args, **kwargs):
        self.spawn_func(func, *args, **kwargs)
